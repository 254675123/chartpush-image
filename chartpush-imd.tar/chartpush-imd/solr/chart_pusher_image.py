# -*- coding: utf-8 -*-
# coding=utf-8

import time
import json
import logging
import datetime

from mysql.connector import Error

from config import config
from database import tool
from database.mongodb import Mongodb
from database.mysqldb import Mysqldb
from solr.solr_server import SolrServer
from duplicate_removal import ChartDuplicate
from multiple_thread.thread_manager import ThreadManager
from algorithm.kmeans_wordsize import KmeansWordSize
from chart_builder_items import BuilderChartItems


class ChartPusher(BuilderChartItems):
    """
    推送算法团队识别的图表到索引
    """

    def __init__(self):
        super(ChartPusher,self).__init__()
        self.__sleep_time_per_request = 0.01
        self.__sleep_time_per_request_none = 180.00
        self.__sleep_time_per_loop = 60
        self.__page_size = 1
        self.__total_num = 0
        self.__recovery = True

        self.__word_size = []
        self.thread_manager = ThreadManager(1)
        self.collection = Mongodb.getMongodbCollection('hb_charts')


    @staticmethod
    def start(target):
        pusher = ChartPusher()

        pusher.__dispatchTask(target)

    def __dispatchTask(self, target):
        # '/niub/www/sourcecode/ResearchReporterTool-2.4-ssd-123/image_ids_isolate'+ str(target)
        logging.info('target:'+str(target))
        if target == '0':
            logging.info('read file')
            image_ids = open('image_ids', 'r')
            ids_lines = image_ids.readlines()

        else:
            logging.info('parameter:'+target)
            ids_lines = target.split(',')

        for line in ids_lines:
            id = line.strip('\n')
            id = id.strip('\r')

            logging.info('Start to select data')

            logging.info('the id is :' + str(id))
            chart_items = self.collection.find({'_id': id})

            #chart_items = self.collection.find({'text_info': {'$exists': 1}})

            # print chart_items
            chart_items = self.convertRecordsToArray(chart_items)
            length = len(chart_items)
            logging.info(length)
            logging.info('Finished to select data')
            if length == 0:
                time.sleep(self.__sleep_time_per_request_none)
            else:
                self.thread_manager.run(chart_items, self.__updateThreadFunc, target=target)
                time.sleep(self.__sleep_time_per_request)
        image_ids.close()
        logging.info('Done')



    def __updateThreadFunc(self, data, args):
        target = args['target']
        thread_id = args['__thread_id']
        chart_items, id_list = self.buildUpdateItems(data)

        code = self.pushIndex(chart_items, thread_id)
        if code == 200:
            #self.collection.update({'_id': {'$in': id_list}}, {'$set': {'state': target}}, multi=True)
            logging.info("push success.")

        # sleep 60s per request fail
        elif code == 402:
            logging.error('Failed to push index, code:' + str(code))
            logging.error('Start waiting crf service recovery ...')
            self.__sleep_time_per_request = 60
            self.__total_num = 0
            self.__recovery = False
            self.__page_size = 1
        # exception process
        else:
            logging.error('Failed to push index, code:' + str(code))
            logging.error('Start judging data and repush index ...')
            self.__total_num = 0
            self.__recovery = False
            if self.__page_size > 30:
                self.__page_size = 30
                logging.error('set page size to 30')
            elif self.__page_size == 30:
                self.__page_size = 1
                logging.error('set page size to 1')
            else:
                id_list = []
                for item in chart_items:
                    id_list.append(item['image_id'])
                    print item['image_id']
                    logging.error('error image_id:' + item['image_id'])
                #self.collection.update({'_id': {'$in': id_list}}, {'$set': {'state': -3}}, multi=True)
                #self.__writeFile(chart_items)
                logging.error('set record state to -3')
        logging.info('push index,code:' + str(code))






